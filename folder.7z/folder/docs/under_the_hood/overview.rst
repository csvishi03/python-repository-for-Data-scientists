Under the Hood
==============

This section of the documentation describes the more techical aspects of the
way in which the Knowledge Repo is implemented. At present, the details provided
here are relatively basic. Eventually, full API documentation should be present
here. Contributions welcome!

.. toctree::

    technical_details
