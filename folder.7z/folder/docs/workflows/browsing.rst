Browsing
========

While the web app interface is designed to be intuitive, it would be great
to have some documentation. Contributions are welcome!

..

  TODO: Add the following? Make sure it is correct.

  Tags are one of the main organizing principles of the knowledge repo web app, and it is important to have high integrity on these tag names. For example, having one post tagged as "my_project" and another as "my-project" or "my_projects" prevents these posts from being organized together.

  We currently have two ways to maintain tag integrity:

   - Browse the `/cluster?group_by=tags` endpoint to find and match existing tags.
   - After contributing, organize tags in batch with the `/batch_tags` end point.
