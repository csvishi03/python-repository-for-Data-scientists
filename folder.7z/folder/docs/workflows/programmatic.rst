Programmatic Interface
======================

It is possible to use the `knowledge_repo` python library to programmatically
interact with knowledge repositories in Python. It would be helpful to have a
few examples of this. Contributions welcome!
